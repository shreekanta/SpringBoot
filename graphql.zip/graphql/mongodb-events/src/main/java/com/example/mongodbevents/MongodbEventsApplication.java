package com.example.mongodbevents;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongodbEventsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MongodbEventsApplication.class, args);
	}

}
