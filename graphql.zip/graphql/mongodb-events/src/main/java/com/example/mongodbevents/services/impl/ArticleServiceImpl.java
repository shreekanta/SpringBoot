package com.example.mongodbevents.services.impl;

import com.example.mongodbevents.dao.ArticleRepository;
import com.example.mongodbevents.model.Article;
import com.example.mongodbevents.services.ArticleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ArticleServiceImpl implements ArticleService {
	private final ArticleRepository articleRepository;

	@Autowired
	ArticleServiceImpl(ArticleRepository articleRepository){
		this.articleRepository = articleRepository;
	}

	@Override
	public List<Article> findAllUserArticles(List<String> ids) {
		return articleRepository.findByIdIn(ids);
	}
}
