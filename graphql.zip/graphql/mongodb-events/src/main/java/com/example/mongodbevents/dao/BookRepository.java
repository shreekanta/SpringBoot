package com.example.mongodbevents.dao;

import com.example.mongodbevents.model.Book;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface BookRepository extends MongoRepository<Book,Integer> {
}
