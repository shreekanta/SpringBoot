package com.example.mongodbevents.services;

import com.example.mongodbevents.model.Article;

import java.util.List;

public interface ArticleService {
	List<Article> findAllUserArticles(List<String> userId);
}
