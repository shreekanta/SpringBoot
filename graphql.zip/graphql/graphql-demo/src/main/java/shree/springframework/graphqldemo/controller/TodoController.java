package shree.springframework.graphqldemo.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;
import shree.springframework.graphqldemo.entity.Todo;
import shree.springframework.graphqldemo.service.TodoService;

import java.util.List;
import java.util.Optional;

/*
@Controller
@RequiredArgsConstructor
public class TodoController {
	private final TodoService todoService;

	@QueryMapping
	public Optional<Todo> todo(@Argument Long id) {
		return todoService.getTodo(id);
	}

	@QueryMapping
	public List<Todo> todos(@Argument Integer count) {
		return todoService.getTodos(count.longValue());
	}

	@MutationMapping
	public Todo createTodo(@Argument String text) {
		return todoService.createTodo(text);
	}

	@MutationMapping
	public Todo toggleTodo(@Argument Long id) {
		return todoService.toggleTodoById(id);
	}

	@MutationMapping
	public Todo deleteTodo(@Argument Long id) {
		return todoService.deleteTodoById(id);
	}

	@MutationMapping
	public List<Todo> deleteAllTodos() {
		return todoService.deleteAllTodos();
	}
}
*/
