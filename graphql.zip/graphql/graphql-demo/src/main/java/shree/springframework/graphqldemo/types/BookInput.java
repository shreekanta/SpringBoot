package shree.springframework.graphqldemo.types;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BookInput {
	String name;
	String pageCount;
}