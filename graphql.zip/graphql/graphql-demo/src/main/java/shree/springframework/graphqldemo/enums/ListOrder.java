package shree.springframework.graphqldemo.enums;

public enum ListOrder {
	ASC,
	DESC
}
