package shree.springframework.graphqldemo.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.Accessors;

import java.io.Serializable;


@Getter
@Setter
@NoArgsConstructor
@Entity
public class Todo implements Serializable {

	@Id
	@GeneratedValue
	private Long id;
	private String text = "";
	private Boolean completed = false;

	@Builder
	public Todo(String text) {
		this.text = text;
	}

	public Todo toggle() {
		completed = !completed;
		return this;
	}

}