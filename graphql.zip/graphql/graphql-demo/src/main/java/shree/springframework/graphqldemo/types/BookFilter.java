package shree.springframework.graphqldemo.types;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BookFilter {
	private String name;
}