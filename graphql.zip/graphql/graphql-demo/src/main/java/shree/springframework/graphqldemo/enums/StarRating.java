package shree.springframework.graphqldemo.enums;

public enum StarRating {
	_1,
	_2,
	_3,
	_4,
	_5
}
