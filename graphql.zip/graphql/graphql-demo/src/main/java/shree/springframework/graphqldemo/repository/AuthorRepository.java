package shree.springframework.graphqldemo.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import shree.springframework.graphqldemo.entity.Author;

@Repository
public interface AuthorRepository extends CrudRepository<Author, Integer> {
	Iterable<Author> findALLByBookId(Integer bookId);
}
