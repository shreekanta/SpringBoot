package com.example.customannotation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomannotationApplicationTests {

	@Test
	void contextLoads() {
	}

}
