package com.example.customannotation.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.customannotation.model.User;



@RestController
@RequestMapping("/users")
public class UserController {

	@RequestMapping("/{userId}")
	@LogExecutionTime
    public User getUserInfo(@PathVariable("userId") String userId) {
		return new User(userId, "Shrik", "Bengaluru");

    }
}

